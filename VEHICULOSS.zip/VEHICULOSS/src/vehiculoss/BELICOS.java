/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package vehiculoss;

/**
 *
 * @author diegomarquezgomez
 */
public interface BELICOS {
    public void DISPARAR();
    public void RECARGAR();
    public void APUNTAR();
}
