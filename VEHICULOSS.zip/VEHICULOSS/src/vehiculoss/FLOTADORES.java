
package vehiculoss;

public interface FLOTADORES {
    public void FLOTAR();
    public void HUNDIR();
}
