
package vehiculoss;

public interface TRANSPORTE {
    public void DESPLAZAR();
    public void FRENAR();
    public void ACELERAR();
}

